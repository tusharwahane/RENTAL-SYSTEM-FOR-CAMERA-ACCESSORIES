//import image from "../images/CategoryImg/Engine/cylinder.gif"

import Navbar from "../../Components/Navigation/Navbar"

const Contact = () => {
    return (
        <div>
            <Navbar />
            <div className="main text-center" >
                <h3>Contact Us  </h3>
                <h5>Name : Samadhan</h5>
                <h5>Email : samadhan563@gmail.com</h5>
                <h5>Contact No : +91 9527644283</h5>
            </div>

        </div>
    );
}
export default Contact