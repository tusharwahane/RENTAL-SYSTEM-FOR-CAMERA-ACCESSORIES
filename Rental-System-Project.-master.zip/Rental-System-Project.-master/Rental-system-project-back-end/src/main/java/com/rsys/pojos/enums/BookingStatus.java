package com.rsys.pojos.enums;

public enum BookingStatus {
	PENDING, ACCEPTED,DELIVERED,RECIVED_AT_CENTER,PICKUPED_BY_CUSTOMER, CANCELED
}
