package com.rsys.controller;

public class Constant {
	public static final String SIGN_IN_ACTION = "/sign-in";
	public static final String FORGOT_PASSWORD_ACTION =  "/forgot-password";
	public static final String RESET_PASSWORD_ACTION =  "/reset-password";	
}
