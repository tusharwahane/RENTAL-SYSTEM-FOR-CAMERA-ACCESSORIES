package com.rsys.pojos.enums;

public enum Currency {
	INR, USD,GDP
}
