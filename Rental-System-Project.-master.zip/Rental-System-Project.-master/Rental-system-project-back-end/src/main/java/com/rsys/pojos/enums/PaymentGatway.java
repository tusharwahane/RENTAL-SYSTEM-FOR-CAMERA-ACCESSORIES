package com.rsys.pojos.enums;

public enum PaymentGatway {
	CARD,CASH_ON_DELIVERY,UPI,GPAY
}
