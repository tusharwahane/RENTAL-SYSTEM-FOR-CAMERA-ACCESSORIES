package com.rsys.pojos.enums;

public enum UserRole {
	ADMIN, CUSTOMER
}
