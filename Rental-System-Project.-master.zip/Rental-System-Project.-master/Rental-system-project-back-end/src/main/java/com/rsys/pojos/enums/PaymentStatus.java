package com.rsys.pojos.enums;

public enum PaymentStatus {
	PENDING, FAILED, PAID
}
