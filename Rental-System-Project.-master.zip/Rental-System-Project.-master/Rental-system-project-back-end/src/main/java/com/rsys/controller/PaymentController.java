package com.rsys.controller;

public class PaymentController {
public PaymentController() {
	System.out.println("Constructor");
}
}
